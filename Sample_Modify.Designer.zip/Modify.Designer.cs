﻿namespace MotoShop
{
    partial class Modify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tbxBrand = new TextBox();
            tbxModel = new TextBox();
            tbxTrans = new TextBox();
            tbxDesc = new TextBox();
            tbxPrice = new TextBox();
            tbxSquantity = new TextBox();
            tbxStatus = new TextBox();
            tbxPname = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label9 = new Label();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnDone = new Button();
            dgvProduct = new DataGridView();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)dgvProduct).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // tbxBrand
            // 
            tbxBrand.Font = new Font("Tahoma", 16.2F);
            tbxBrand.Location = new Point(12, 138);
            tbxBrand.Name = "tbxBrand";
            tbxBrand.Size = new Size(354, 40);
            tbxBrand.TabIndex = 0;
            // 
            // tbxModel
            // 
            tbxModel.Font = new Font("Tahoma", 16.2F);
            tbxModel.Location = new Point(12, 375);
            tbxModel.Name = "tbxModel";
            tbxModel.Size = new Size(354, 40);
            tbxModel.TabIndex = 1;
            // 
            // tbxTrans
            // 
            tbxTrans.Font = new Font("Tahoma", 16.2F);
            tbxTrans.Location = new Point(12, 217);
            tbxTrans.Name = "tbxTrans";
            tbxTrans.Size = new Size(354, 40);
            tbxTrans.TabIndex = 1;
            // 
            // tbxDesc
            // 
            tbxDesc.Font = new Font("Tahoma", 16.2F);
            tbxDesc.Location = new Point(12, 614);
            tbxDesc.Multiline = true;
            tbxDesc.Name = "tbxDesc";
            tbxDesc.Size = new Size(354, 104);
            tbxDesc.TabIndex = 1;
            // 
            // tbxPrice
            // 
            tbxPrice.Font = new Font("Tahoma", 16.2F);
            tbxPrice.Location = new Point(12, 294);
            tbxPrice.Name = "tbxPrice";
            tbxPrice.Size = new Size(354, 40);
            tbxPrice.TabIndex = 1;
            // 
            // tbxSquantity
            // 
            tbxSquantity.Font = new Font("Tahoma", 16.2F);
            tbxSquantity.Location = new Point(12, 443);
            tbxSquantity.Name = "tbxSquantity";
            tbxSquantity.Size = new Size(354, 40);
            tbxSquantity.TabIndex = 2;
            // 
            // tbxStatus
            // 
            tbxStatus.Font = new Font("Tahoma", 16.2F);
            tbxStatus.Location = new Point(12, 515);
            tbxStatus.Name = "tbxStatus";
            tbxStatus.Size = new Size(354, 40);
            tbxStatus.TabIndex = 4;
            // 
            // tbxPname
            // 
            tbxPname.Font = new Font("Tahoma", 16.2F);
            tbxPname.Location = new Point(12, 57);
            tbxPname.Name = "tbxPname";
            tbxPname.Size = new Size(354, 40);
            tbxPname.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 32);
            label1.Name = "label1";
            label1.Size = new Size(139, 22);
            label1.TabIndex = 7;
            label1.Text = "Product Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(12, 113);
            label2.Name = "label2";
            label2.Size = new Size(64, 22);
            label2.TabIndex = 8;
            label2.Text = "Brand";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(12, 190);
            label3.Name = "label3";
            label3.Size = new Size(129, 22);
            label3.TabIndex = 9;
            label3.Text = "Transmission";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(12, 269);
            label4.Name = "label4";
            label4.Size = new Size(56, 22);
            label4.TabIndex = 10;
            label4.Text = "Price";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(12, 344);
            label5.Name = "label5";
            label5.Size = new Size(64, 22);
            label5.TabIndex = 11;
            label5.Text = "Model";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label6.ForeColor = Color.White;
            label6.Location = new Point(9, 573);
            label6.Name = "label6";
            label6.Size = new Size(113, 22);
            label6.TabIndex = 12;
            label6.Text = "Description";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label7.ForeColor = Color.White;
            label7.Location = new Point(12, 418);
            label7.Name = "label7";
            label7.Size = new Size(143, 22);
            label7.TabIndex = 13;
            label7.Text = "Stock Quantity";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Tahoma", 10.8F, FontStyle.Bold);
            label9.ForeColor = Color.White;
            label9.Location = new Point(9, 490);
            label9.Name = "label9";
            label9.Size = new Size(67, 22);
            label9.TabIndex = 15;
            label9.Text = "Status";
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Tahoma", 16.2F, FontStyle.Bold);
            btnAdd.Location = new Point(12, 754);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(158, 49);
            btnAdd.TabIndex = 16;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Font = new Font("Tahoma", 16.2F, FontStyle.Bold);
            btnUpdate.Location = new Point(194, 754);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(172, 49);
            btnUpdate.TabIndex = 17;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.Font = new Font("Tahoma", 16.2F, FontStyle.Bold);
            btnDelete.Location = new Point(12, 850);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(158, 49);
            btnDelete.TabIndex = 18;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnDone
            // 
            btnDone.Font = new Font("Tahoma", 16.2F, FontStyle.Bold);
            btnDone.Location = new Point(194, 850);
            btnDone.Name = "btnDone";
            btnDone.Size = new Size(172, 49);
            btnDone.TabIndex = 19;
            btnDone.Text = "Done";
            btnDone.UseVisualStyleBackColor = true;
            btnDone.Click += btnDone_Click;
            // 
            // dgvProduct
            // 
            dgvProduct.BackgroundColor = Color.DarkSlateGray;
            dgvProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProduct.Dock = DockStyle.Right;
            dgvProduct.Location = new Point(392, 0);
            dgvProduct.Name = "dgvProduct";
            dgvProduct.RowHeadersWidth = 51;
            dgvProduct.Size = new Size(1090, 953);
            dgvProduct.TabIndex = 20;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(btnDone);
            panel1.Controls.Add(btnDelete);
            panel1.Controls.Add(btnUpdate);
            panel1.Controls.Add(btnAdd);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(tbxPname);
            panel1.Controls.Add(tbxStatus);
            panel1.Controls.Add(tbxSquantity);
            panel1.Controls.Add(tbxPrice);
            panel1.Controls.Add(tbxDesc);
            panel1.Controls.Add(tbxTrans);
            panel1.Controls.Add(tbxModel);
            panel1.Controls.Add(tbxBrand);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(396, 953);
            panel1.TabIndex = 22;
            // 
            // Modify
            // 
            AutoScaleDimensions = new SizeF(9F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1482, 953);
            Controls.Add(panel1);
            Controls.Add(dgvProduct);
            Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Modify";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Modify";
            ((System.ComponentModel.ISupportInitialize)dgvProduct).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox tbxBrand;
        private TextBox tbxModel;
        private TextBox tbxTrans;
        private TextBox tbxDesc;
        private TextBox tbxPrice;
        private TextBox tbxSquantity;
        private TextBox tbxStatus;
        private TextBox tbxPname;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label9;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnDone;
        private DataGridView dgvProduct;
        private Panel panel1;
    }
}